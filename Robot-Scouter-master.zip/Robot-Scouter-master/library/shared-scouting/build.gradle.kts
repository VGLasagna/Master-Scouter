dependencies {
    api(project(":library:shared"))

    implementation(Config.Libs.Jetpack.cardView)
    implementation(Config.Libs.Misc.snap)
}
