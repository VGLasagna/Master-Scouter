package com.supercilex.robotscouter.core.model

interface OrderedModel {
    var position: Int
}
