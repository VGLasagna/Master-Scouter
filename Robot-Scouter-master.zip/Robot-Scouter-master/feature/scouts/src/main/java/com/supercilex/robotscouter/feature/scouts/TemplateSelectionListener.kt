package com.supercilex.robotscouter.feature.scouts

interface TemplateSelectionListener {
    fun onTemplateSelected(id: String)
}
