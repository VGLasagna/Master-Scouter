dependencies {
    implementation(project(":app:android-base"))
    implementation(project(":library:shared-scouting"))

    implementation(Config.Libs.Firebase.links)
}
