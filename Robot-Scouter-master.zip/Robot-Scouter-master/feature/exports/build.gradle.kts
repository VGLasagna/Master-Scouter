dependencies {
    implementation(project(":app:android-base"))
    implementation(project(":library:shared"))

    implementation(Config.Libs.Misc.poi)
    implementation(Config.Libs.Misc.poiProguard)
    implementation(Config.Libs.Misc.gson)
}
