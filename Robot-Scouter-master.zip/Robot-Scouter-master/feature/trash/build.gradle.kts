dependencies {
    implementation(project(":app:android-base"))
    implementation(project(":library:shared"))
}
