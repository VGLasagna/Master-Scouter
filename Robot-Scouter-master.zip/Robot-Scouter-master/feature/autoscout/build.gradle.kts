dependencies {
    implementation(project(":app:android-base"))
    implementation(project(":library:shared"))

    implementation(Config.Libs.PlayServices.nearby)
}
